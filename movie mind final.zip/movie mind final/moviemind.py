from flask import Flask, render_template, request
import pandas as pd
import json
import os
import ast
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Flask app initialization
app = Flask(__name__)

movies_file = "C:/Users/paata/Desktop/movie mind final/mm/tmdb_5000_movies.csv"
credits_file = "C:/Users/paata/Desktop/movie mind final/mm/tmdb_5000_credits.csv"
cleaned_data_file = "C:/Users/paata/Desktop/movie mind final/mm/cleaned_movie_data.csv"
user_feedback_file = "C:/Users/paata/Desktop/movie mind final/mm/agreed_movies.json"

# Load and clean movies dataset
movies_df = pd.read_csv(
    movies_file, 
    usecols=['id', 'genres', 'keywords', 'release_date'], 
    dtype={'id': 'int32', 'genres': 'str', 'keywords': 'str', 'release_date': 'str'}
)

# Load and clean credits dataset
credits_df = pd.read_csv(
    credits_file,
    usecols=['movie_id', 'title'],  # Ensure 'title' column exists in credits file
    dtype={'movie_id': 'str', 'title': 'str'}
)

credits_df['movie_id'] = pd.to_numeric(credits_df['movie_id'], errors='coerce')
credits_df = credits_df.dropna(subset=['movie_id'])
credits_df['movie_id'] = credits_df['movie_id'].astype('int32')

# Merge datasets and replace movie titles
merged_df = movies_df.merge(credits_df, left_on='id', right_on='movie_id')
merged_df.rename(columns={'title': 'final_title'}, inplace=True)  # Use the title from credits_df

def parse_column(column_data):
    try:
        return ' '.join([entry['name'] for entry in ast.literal_eval(column_data)])
    except (ValueError, SyntaxError, TypeError):
        return ''

merged_df['genres_parsed'] = merged_df['genres'].apply(parse_column)
merged_df['keywords_parsed'] = merged_df['keywords'].apply(parse_column)
merged_df['combined_features'] = merged_df['genres_parsed'] + ' ' + merged_df['keywords_parsed']

# Keep necessary columns
merged_df = merged_df[['final_title', 'combined_features']]

# Save cleaned dataset to CSV
merged_df.to_csv(cleaned_data_file, index=False)

# Create count matrix and cosine similarity
count_vectorizer = CountVectorizer(stop_words='english')
count_matrix = count_vectorizer.fit_transform(merged_df['combined_features'])
cosine_sim = cosine_similarity(count_matrix)

# Load existing feedback
if os.path.exists(user_feedback_file):
    with open(user_feedback_file, 'r') as f:
        user_feedback = json.load(f)
else:
    user_feedback = {}

# Recommendation function
def recommend_movies(title, refine_mode=False):
    title = title.strip().lower()
    idx = merged_df[merged_df['final_title'].str.lower() == title].index
    if idx.empty:
        return ["Movie not found. Please try another."]
    idx = idx[0]
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)[1:13]
    recommendations = [merged_df.iloc[i[0]]['final_title'] for i in sim_scores]

    # Exclude unliked movies in refined mode
    if refine_mode and title in user_feedback:
        recommendations = [movie for movie in recommendations if movie not in user_feedback[title]]

    return recommendations

@app.route('/')
def root():
    return render_template('index.html', recommendations=[])

@app.route('/search', methods=['GET'])
def search():
    movie_name = request.args.get('query', '').strip()
    mode = request.args.get('mode', 'initial')
    refine_mode = True if mode == 'refine' else False
    recommendations = recommend_movies(movie_name, refine_mode=refine_mode) if movie_name else []
    return render_template('index.html', recommendations=recommendations, movie_name=movie_name, mode=mode)

@app.route('/feedback', methods=['POST'])
def feedback(): 
    movie_name = request.form.get('movie_name', '').strip().lower()
    unliked_movies = request.form.getlist('unliked_movies')
    
    if movie_name and unliked_movies:
        if movie_name not in user_feedback:
            user_feedback[movie_name] = []
        user_feedback[movie_name].extend(unliked_movies)
        user_feedback[movie_name] = list(set(user_feedback[movie_name]))  # Ensure unique entries
        
        # Save feedback to JSON
        with open(user_feedback_file, 'w') as f:
            json.dump(user_feedback, f, indent=4)
    
    return render_template('index.html', recommendations=[], movie_name=movie_name, feedback_saved=True)

if __name__ == '__main__':
    app.run(debug=True)



